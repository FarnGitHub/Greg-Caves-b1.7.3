package worldsettings;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.logging.Logger;

import worldsettings.api.settings.Serializable;
import worldsettings.api.settings.SettingSupplier;

class Serialization {
	private static final Logger LOGGER = WorldSettings.getLogger();
	private static final Map<Class<?>, Function<Object, String>> SERIALIZERS = new HashMap<>();
	private static final Map<Class<?>, Function<String, Object>> DESERIALIZERS = new HashMap<>();
	
	static {
		registerSerializer(Boolean.class, b -> b.toString());
		registerDeserializer(Boolean.class, string -> Boolean.valueOf(string));

		registerSerializer(Byte.class, b -> b.toString());
		registerDeserializer(Byte.class, string -> Byte.valueOf(string));

		registerSerializer(Short.class, s -> s.toString());
		registerDeserializer(Short.class, string -> Short.valueOf(string));

		registerSerializer(Integer.class, i -> i.toString());
		registerDeserializer(Integer.class, string -> Integer.valueOf(string));

		registerSerializer(Long.class, l -> l.toString());
		registerDeserializer(Long.class, string -> Long.valueOf(string));

		registerSerializer(Float.class, f -> f.toString());
		registerDeserializer(Float.class, string -> Float.valueOf(string));

		registerSerializer(Double.class, d -> d.toString());
		registerDeserializer(Double.class, string -> Double.valueOf(string));

		registerSerializer(Character.class, c -> c.toString());
		registerDeserializer(Character.class, string -> Character.valueOf(string.charAt(0)));

		registerSerializer(String.class, string -> (String) string);
		registerDeserializer(String.class, string -> string);
	}
	
	public static void registerSerializer(Class<?> key, Function<Object, String> function) {
		if (SERIALIZERS.containsKey(key)) {
			LOGGER.severe("Tried adding a serializer for a class that already has a serializer");
			return;
		}
		
		SERIALIZERS.put(key, function);
	}
	
	public static void registerDeserializer(Class<?> key,  Function<String, Object> function) {
		if (DESERIALIZERS.containsKey(key)) {
			LOGGER.severe("Tried adding a deserializer for a class that already has a deserializer");
			return;
		}
		
		DESERIALIZERS.put(key, function);
	}
	
	public static String serialize(SettingSupplier<?> setting) {
		if (setting instanceof Serializable) {
			String serialized = ((Serializable) setting).serialize();
			if (serialized == null) {
				LOGGER.warning("Tried serializing Setting: " + setting.getKey() + " and failed while using a custom implementation");
				return null;
			}
			
			return serialized;
		}
		
		Object value = setting.getValue();
		if (value == null) {
			LOGGER.severe("Tried serializing a null object");
			return null;
		}
		
		Class<?> clazz = value.getClass();
		if (clazz == null) {
			LOGGER.severe("Could not get the class of a value while serializing");
		}
		
		if (!SERIALIZERS.containsKey(clazz)) {
			LOGGER.severe("Tried serializing a string with no available serializers");
			return null;
		}
		
		try {
			Function<Object, String> serializer = SERIALIZERS.get(clazz);
			return serializer != null ? serializer.apply(value) : null;
		} catch (Exception e) {
			return null;
		}
	}
	
	public static void deserialize(SettingSupplier<Object> setting, String property) {
		Class<?> valueClass = setting.getValueClass();
		if (!DESERIALIZERS.containsKey(valueClass)) {
			LOGGER.severe("Tried deserializing a string with no available deserializers");
			return;
		}
		
		if (setting instanceof Serializable) {
			((Serializable) setting).deserialize(property);
			return;
		}
		
		try {
			Function<String, Object> deserializer = DESERIALIZERS.get(valueClass);
			if (deserializer == null) {
				return;
			}
			
			Object object = deserializer.apply(property);
			setting.setValue(object);
		} catch (Exception e) {
			
		}
	}
	
}
