package worldsettings;

import java.io.File;

import net.minecraft.client.Minecraft;
import net.minecraft.src.GuiButton;
import net.minecraft.src.GuiSelectWorld;
import net.minecraft.src.SaveFormatComparator;

public class GuiSelectWorldButton extends GuiButton {
	public static final int NO_SELECTED_WORLD = -1;
	
	private int lastSelectedWorld = NO_SELECTED_WORLD;
	
	private final GuiSelectWorld guiSelectWorld;
	
	public GuiSelectWorldButton(int id, int x, int y, int width, int height, String text, GuiSelectWorld guiSelectWorld) {
		super(id, x, y, width, height, text);
		this.guiSelectWorld = guiSelectWorld;
	}

	@Override
	public void drawButton(Minecraft minecraft, int x, int y) {
		int selectedWorld = WorldSettings.PackageAccess.GuiSelectWorld.getSelectedWorld(this.guiSelectWorld);
		if (this.guiSelectWorld != null && selectedWorld != NO_SELECTED_WORLD) {
			if (this.lastSelectedWorld != selectedWorld && this.enabled) {
				reloadConfiguration();
				this.lastSelectedWorld = selectedWorld;
			}
			
			this.enabled = true;
		} else {
			this.enabled = false;
		}
		
		super.drawButton(minecraft, x, y);
	}
	
	public void reloadConfiguration() {
		SaveFormatComparator saveFormatComparator = WorldSettings.getSelectedSaveFormatComparator(this.guiSelectWorld);
		if (saveFormatComparator == null) {
			return;
		}
		
		File saveDirectory = WorldSettings.getSaveDirectory(saveFormatComparator);
		if (saveDirectory == null) {
			return;
		}
		
		File configurationDirectory = WorldSettingsConfiguration.getConfigurationDirectory(saveDirectory);
		if (configurationDirectory == null) {
			return;
		}
		
		WorldSettingsConfiguration.loadConfigurations(configurationDirectory);
	}
	
}
