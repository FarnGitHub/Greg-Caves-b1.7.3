package worldsettings;

import java.util.List;

import net.minecraft.src.GuiButton;
import net.minecraft.src.GuiCreateWorld;
import net.minecraft.src.GuiScreen;
import net.minecraft.src.ModLoader;
import net.minecraft.src.StringTranslate;
import net.minecraft.src.overrideapi.OverrideAPI;
import net.minecraft.src.overrideapi.utils.gui.ButtonHandler;

public class ButtonHandlerCreateWorld implements ButtonHandler {
	
	private static final int CREATE_BUTTON_ID = 0;
	private static final int CANCEL_BUTTON_ID = 1;
	private int worldGenButtonID;
	private GuiButton worldGenButton;
	
	@Override
	public void initGui(GuiScreen guiScreen, List<GuiButton> customButtons) {
		if (guiScreen instanceof GuiCreateWorld) {
			for (int i = 0; i < customButtons.size(); ++i) {
				GuiButton button = customButtons.get(i);
				if (button.id == CREATE_BUTTON_ID) {
					String displayString = button.displayString;
					button = null;
					customButtons.set(i, new GuiButton(CREATE_BUTTON_ID, guiScreen.width / 2 - 154, guiScreen.height - 28, 150, 20, displayString));
				} else if (button.id == CANCEL_BUTTON_ID) {
					String displayString = button.displayString;
					button = null;
					customButtons.set(i, new GuiButton(CANCEL_BUTTON_ID, guiScreen.width / 2 + 4, guiScreen.height - 28, 150, 20, displayString));
				}
				
			}
			
			this.worldGenButtonID = OverrideAPI.getUniqueButtonID();
			StringTranslate stringTranslate = StringTranslate.getInstance();
			this.worldGenButton = new GuiButton(this.worldGenButtonID, guiScreen.width / 2 - 100, 172, 200, 20, stringTranslate.translateKey(WorldSettings.KEY_LANG_OPTIONS));			
			customButtons.add(this.worldGenButton);
			this.whymine_diver = true;
			return;
		}
		
		this.whymine_diver = false;
	}
	
	private boolean whymine_diver = true;

	@Override
	public void actionPerformed(GuiScreen guiScreen, GuiButton guiButton) {
		if (this.whymine_diver && guiScreen instanceof GuiCreateWorld && guiButton == this.worldGenButton && guiButton.id == this.worldGenButtonID && guiButton.enabled) {
			StringTranslate stringTranslate = StringTranslate.getInstance();
			WorldSettingsConfiguration.resetConfigurations();
			ModLoader.getMinecraftInstance().displayGuiScreen(new GuiWorldSettings(guiScreen, stringTranslate.translateKey(WorldSettings.KEY_LANG_OPTIONS), null));
			return;
		}
		
		this.whymine_diver = true;
	}

}
