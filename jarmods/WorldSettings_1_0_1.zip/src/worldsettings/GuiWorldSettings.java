package worldsettings;

import java.io.File;

import net.minecraft.client.Minecraft;
import net.minecraft.src.GuiButton;
import net.minecraft.src.GuiScreen;
import net.minecraft.src.StringTranslate;
import worldsettings.api.settings.ConfigurationSupplier;

public class GuiWorldSettings extends GuiScreen {
	public final static int CONFIGURE_BUTTON_ID = 0;
	public final static int RESET_BUTTON_ID = 1;
	public final static int DONE_BUTTON_ID = 2;
	public final static int SCROLL_UP_BUTTON_ID = 3;
	public final static int SCROLL_DOWN_BUTTON_ID = 4;
	
	public final GuiScreen parentScreen;
	public final String worldDisplayName;
	public final File configurationDirectory;
	
	private GuiButton guiButtonConfigure;
	private GuiButton guiButtonReset;
	private GuiButton guiButtonDone;
	
	private GuiWorldSettingsSlot guiWorldGenSlot;
	
	public GuiWorldSettings(GuiScreen parentScreen, String worldDisplayName, File configurationDirectory) {
		this.parentScreen = parentScreen;
		this.worldDisplayName = worldDisplayName;
		this.configurationDirectory = configurationDirectory;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public void initGui() {
		StringTranslate stringTranslate = StringTranslate.getInstance();
		this.guiButtonConfigure = new GuiButton(CONFIGURE_BUTTON_ID, this.width / 2 - 147 - 4, this.height - 28, 98, 20, stringTranslate.translateKey(WorldSettings.KEY_LANG_CONFIGURE));		
		this.guiButtonConfigure.enabled = false;
		this.controlList.add(this.guiButtonConfigure);
		this.guiButtonReset = new GuiButton(RESET_BUTTON_ID, this.width / 2 - 49, this.height - 28, 98, 20, stringTranslate.translateKey(WorldSettings.KEY_LANG_RESET));
		this.guiButtonReset.enabled = false;
		this.controlList.add(this.guiButtonReset);
		this.guiButtonDone = new GuiButton(DONE_BUTTON_ID, this.width / 2 + 49 + 4, this.height - 28, 98, 20, stringTranslate.translateKey("gui.done"));
		this.controlList.add(this.guiButtonDone);
		this.guiWorldGenSlot = new GuiWorldSettingsSlot(this);
		this.guiWorldGenSlot.registerScrollButtons(this.controlList, SCROLL_UP_BUTTON_ID, SCROLL_DOWN_BUTTON_ID);
	}
	
	@Override
	public void drawScreen(int x, int y, float partialTick) {
		this.guiWorldGenSlot.drawScreen(x, y, partialTick);
		this.drawCenteredString(this.fontRenderer, this.worldDisplayName, this.width / 2, 20, 0xFFFFFF);
		super.drawScreen(x, y, partialTick);
	}
	
	@Override
	protected void actionPerformed(GuiButton guiButton) {
		if (!guiButton.enabled) {
			return;
		}
		
		if (guiButton.id == CONFIGURE_BUTTON_ID) {
			ConfigurationSupplier configuration = this.guiWorldGenSlot.getSelectedConfiguration();
			if (configuration != null) {
				this.guiWorldGenSlot.deselectButton();
				configuration.displayGUI(this.mc, this);
			}
			
			return;
		}
		
		if (guiButton.id == RESET_BUTTON_ID) {
			ConfigurationSupplier configuration = this.guiWorldGenSlot.getSelectedConfiguration();
			if (configuration != null) {
				configuration.reset();
			}
			
			return;
		}
		
		if (guiButton.id == DONE_BUTTON_ID) {
			if (this.configurationDirectory != null) {
				WorldSettingsConfiguration.saveConfigurations(this.configurationDirectory);
			}
			
			this.mc.displayGuiScreen(this.parentScreen);
			return;
		}
		
		this.guiWorldGenSlot.actionPerformed(guiButton);
	}
	
	@Override
	public void onGuiClosed() {		
		this.guiWorldGenSlot.deselectButton();
	}

	public void enableButtons() {
		this.guiButtonConfigure.enabled = true;
		this.guiButtonReset.enabled = true;
	}
	
	static Minecraft getMinecraft(GuiWorldSettings guiWorldGen) {
		return guiWorldGen.mc;
	}
	
}
