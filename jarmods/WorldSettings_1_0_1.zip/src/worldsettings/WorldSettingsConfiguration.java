package worldsettings;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.logging.Logger;

import net.minecraft.src.mod_WorldSettings;
import worldsettings.api.settings.ConfigurationSupplier;
import worldsettings.api.settings.SettingSupplier;

public class WorldSettingsConfiguration {
	private static final List<ConfigurationSupplier> CONFIGURATIONS = new ArrayList<>();
	private static final Logger LOGGER = WorldSettings.getLogger();
	
	public static void resetConfigurations() {
		for (ConfigurationSupplier configuration : CONFIGURATIONS) {
			if (configuration == null) {
				LOGGER.warning("While resetting configurations, tried to reset a null configuration");
			}
			
			configuration.reset();
		}
	}
	
	public static void saveConfigurations(File configurationDirectory) {
		for (ConfigurationSupplier configuration : CONFIGURATIONS) {
			if (configuration == null) {
				LOGGER.severe("Tried saving a null configuration");
				continue;
			}
			
			String name = configuration.getName();
			if (name == null || name.isEmpty()) {
				LOGGER.severe("Could not save: " + configuration + " because it does not have a name");
				continue;
			}
			
			if (saveConfiguration(configurationDirectory, configuration, name)) {
				LOGGER.info("Saved: " + name + " World settings configuration");
				continue;
			}
			
			LOGGER.info("Failed to save: " + name + " World settings configuration");
		}
	}
	
	public static boolean saveConfiguration(File configurationDirectory, ConfigurationSupplier configuration, String name) {	
		Set<String> settings = configuration.keySet();
		if (settings == null) {
			LOGGER.severe("Could not save: " + configuration + " with the name: " + name + " because the settings key set is null");
			return false;
		}
		
		Properties properties = new Properties();
		for (String key : settings) {
			if (key == null) {
				LOGGER.warning("One of the keys was null while loading the configuration: " + configuration + " with the name: " + name);
				continue;
			}
			
			SettingSupplier<Object> setting = configuration.get(key);
			
			if (setting == null) {
				LOGGER.warning("Tried to save a null setting while loading the configuration: " + configuration + " with the name: " + name);
				continue;
			}
			
			String serializedValue = Serialization.serialize(setting);
			if (serializedValue == null || serializedValue.isEmpty()) {
				LOGGER.warning("Serialized output was empty for the key" + key + " while loading the configuration: " + name);
				continue;
			}
			
			properties.setProperty(key, serializedValue);
		}
		
		File propertiesFile = new File(configurationDirectory, name + mod_WorldSettings.propertiesFileExtension);
		if (!configurationDirectory.exists() && !configurationDirectory.mkdirs()) {
			LOGGER.severe("Could not find or create the World settings configuration directory");
			return false;
		} else {
			if (!propertiesFile.exists()) {
				try {
					if (!propertiesFile.createNewFile()) {
						LOGGER.severe("Could not create the properties file for: " + name);
						return false;
					} else {
						LOGGER.info("Created properties file for: " + name);
					}
				} catch (IOException e) {
					e.printStackTrace();
					LOGGER.severe("Could not create the properties file for: " + name);
					return false;
				}
			}
			
			try (FileOutputStream fos = new FileOutputStream(propertiesFile, false)) {
				properties.store(fos, name);
			} catch (IOException e) {
				e.printStackTrace();
				LOGGER.severe("Could not write the properties file for: " + name);
				return false;
			}
		}

		return true;
	}
	
	public static void loadConfigurations(File configurationDirectory) {
		for (ConfigurationSupplier configuration : CONFIGURATIONS) {
			if (configuration == null) {
				LOGGER.severe("Tried loading a null configuration");
				continue;
			}
			
			String name = configuration.getName();
			if (name == null || name.isEmpty()) {
				LOGGER.severe("Could not load: " + configuration + " because it does not have a name");
				continue;
			}
			
			if (loadConfiguration(configurationDirectory, configuration, name)) {
				LOGGER.info("Loaded: " + name + " World settings configuration at: " + configurationDirectory);
				continue;
			}
			
			LOGGER.info("Failed to load: " + name + " World settings configuration");
		}
	}
	
	public static boolean loadConfiguration(File configurationDirectory, ConfigurationSupplier configuration, String name) {
		Set<String> keys = configuration.keySet();
		if (keys == null) {
			LOGGER.severe("Could not load configuration with the name: " + name + " because the key set is are null");
			return false;
		}
		
		Properties properties = new Properties();
		File propertiesFile = new File(configurationDirectory, name + mod_WorldSettings.propertiesFileExtension);
		if (!propertiesFile.exists()) {
			LOGGER.info("Could not load configuration with the name: " + name + " at: " + propertiesFile.getAbsolutePath() + " because it does not exist");
			return false;
		}
		
		try (FileInputStream fis = new FileInputStream(propertiesFile)) {
			properties.load(fis);
			for (String key : keys) {
				if (key == null) {
					LOGGER.warning("One of the keys was null while loading the configuration: " + configuration + " with the name: " + name);
					continue;
				}
				
				SettingSupplier<Object> setting = configuration.get(key);
				if (setting == null) {
					LOGGER.warning("One of the settings was null while loading: " + configuration + " with the name: " + name);
					continue;
				}
				
				String property = properties.getProperty(key);
				if (property == null) {
					LOGGER.warning("Could not load the property: " + key + " while loading the configuration " + configuration + " with the name: " + name);
					setting.resetValue();
					continue;
				}
				
				Serialization.deserialize(setting, property);
			}
		} catch (IOException e) {
			e.printStackTrace();
			LOGGER.info("Could not load the properties file for: " + configuration + " with the name: " + name);
			configuration.reset();
			return false;
		}
		
		return true;
	}
	
	public static File getConfigurationDirectory(File saveDirectory) {
		return new File(saveDirectory, mod_WorldSettings.propertiesDirectory);
	}

	public static void registerConfiguration(ConfigurationSupplier configuration) {
		if (configuration == null)  {
			LOGGER.warning("Tried registering a null configuration");
			return;
		}
		
		if (CONFIGURATIONS.contains(configuration)) {
			LOGGER.warning("Tried registering a configuration that has been already registered");
			return;
		}
		
		CONFIGURATIONS.add(configuration);
	}
	
	public static List<ConfigurationSupplier> getConfigurations() {
		return new ArrayList<ConfigurationSupplier>(CONFIGURATIONS);
	}
	
}
