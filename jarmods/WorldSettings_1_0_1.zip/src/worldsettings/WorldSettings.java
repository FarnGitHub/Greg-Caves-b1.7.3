package worldsettings;

import java.io.File;
import java.util.List;
import java.util.logging.Logger;

import net.minecraft.client.Minecraft;
import net.minecraft.src.GuiScreen;
import net.minecraft.src.GuiSelectWorld;
import net.minecraft.src.ISaveHandler;
import net.minecraft.src.ModLoader;
import net.minecraft.src.SaveFormatComparator;
import net.minecraft.src.SaveHandler;
import net.minecraft.src.World;
import net.minecraft.src.mod_WorldSettings;
import net.minecraft.src.overrideapi.OverrideAPI;

public class WorldSettings {
	
	private static final Logger LOGGER = Logger.getLogger("World Settings");
	
	public static final String KEY_LANG_SELECT_WORLD = "worldsettings.selectworld.options";
	public static final String KEY_LANG_CONFIGURE = "worldsettings.configure";
	public static final String KEY_LANG_RESET = "worldsettings.reset";
	public static final String KEY_LANG_OPTIONS = "worldsettings.options";
	
	private static boolean configurationLoadedInWorld;
	
	public static void init() {
		LOGGER.info("Adding localization");
		ModLoader.AddLocalization(KEY_LANG_SELECT_WORLD, mod_WorldSettings.langSelectWorld);
		ModLoader.AddLocalization(KEY_LANG_CONFIGURE, mod_WorldSettings.langConfigure);
		ModLoader.AddLocalization(KEY_LANG_RESET, mod_WorldSettings.langReset);
		ModLoader.AddLocalization(KEY_LANG_OPTIONS, mod_WorldSettings.langOptions);
	}
	
	public static void modsLoaded() {
		LOGGER.info("Registering select button handlers");
		OverrideAPI.registerButtonHandler(new ButtonHandlerSelectWorld());
		OverrideAPI.registerButtonHandler(new ButtonHandlerCreateWorld());
	}
	
	public static boolean onTickInGUI(Minecraft minecraft, GuiScreen guiScreen) {
		if (minecraft.theWorld == null && configurationLoadedInWorld) {
			LOGGER.info("Setting configuration as unloaded");
			configurationLoadedInWorld = false;
		}
		
		return true;
	}
	
	public static boolean onTickInGame(Minecraft minecraft) {
		World world = minecraft.theWorld;
		if (configurationLoadedInWorld) {
			return true;
		}
		
		if (world.multiplayerWorld) {
			WorldSettingsConfiguration.resetConfigurations();
			configurationLoadedInWorld = true;
			return true;
		}
		
		ISaveHandler saveHandler = PackageAccess.World.getSaveHandler(world);
		File saveDirectory = null;
		if (saveHandler instanceof SaveHandler) {
			saveDirectory = PackageAccess.SaveHandler.getSaveDirectory((SaveHandler) saveHandler);
		} else {
			LOGGER.severe("Could not get the save directory from save handler, World settings will not be saved or be reloaded for this world when playing");
			return true;
		}
		
		if (saveDirectory == null) {
			return true;
		}
		
		File configurationDirectory =  WorldSettingsConfiguration.getConfigurationDirectory(saveDirectory);
		if (configurationDirectory == null) {
			LOGGER.severe("Could not get the configuration directory, World settings will not be saved or reloaded for this world");
			return true;
		}
		
		if (world.isNewWorld) {
			LOGGER.info("Saving the world settings for new world");
			WorldSettingsConfiguration.saveConfigurations(configurationDirectory);
		}
		
		LOGGER.info("Reloading world settings");
		WorldSettingsConfiguration.loadConfigurations(configurationDirectory);
		configurationLoadedInWorld = true;
		return true;
	}
	
	public static Logger getLogger() {
		return LOGGER;
	}
	
	public static File getSaveDirectory(SaveFormatComparator saveFormatComparator) {
		if (saveFormatComparator != null) {
			return new File(Minecraft.getMinecraftDir(), "/saves/" + saveFormatComparator.getFileName());
		}
		
		return null;
	}
	
	public static SaveFormatComparator getSelectedSaveFormatComparator(GuiSelectWorld guiSelectWorld) {
		@SuppressWarnings("rawtypes")
		List list = WorldSettings.PackageAccess.GuiSelectWorld.getSize(guiSelectWorld);
		int comparatorIndex = WorldSettings.PackageAccess.GuiSelectWorld.getSelectedWorld(guiSelectWorld);
		if (list == null || comparatorIndex < 0 || comparatorIndex >= list.size()) {
			return null;
		}
		
		Object object = list.get(comparatorIndex);
		if (object instanceof SaveFormatComparator) {
			return (SaveFormatComparator) object;
		}
		
		return null;
	}
	
	public static class PackageAccess {
		
		public static class GuiSelectWorld {
			
			@SuppressWarnings("rawtypes")
			public static List getSize(net.minecraft.src.GuiSelectWorld guiSelectWorld) {
				return mod_WorldSettings.PackageAccess.GuiSelectWorld.getSize(guiSelectWorld);
			}
			
			
			public static int getSelectedWorld(net.minecraft.src.GuiSelectWorld guiSelectWorld) {
				return mod_WorldSettings.PackageAccess.GuiSelectWorld.getSelectedWorld(guiSelectWorld);
			}
			
		}
		
		public static class World {
			
			public static ISaveHandler getSaveHandler(net.minecraft.src.World world) {
				return mod_WorldSettings.PackageAccess.World.getSaveHandler(world);
			}
			
		}
		
		public static class SaveHandler {
			
			public static File getSaveDirectory(net.minecraft.src.SaveHandler saveHandler) {
				return mod_WorldSettings.PackageAccess.SaveHandler.getSaveDirectory(saveHandler);
			}
			
		}
		
	}
	
}
