package worldsettings;

import java.io.File;
import java.util.List;
import java.util.logging.Logger;

import net.minecraft.src.GuiButton;
import net.minecraft.src.GuiScreen;
import net.minecraft.src.GuiSelectWorld;
import net.minecraft.src.ModLoader;
import net.minecraft.src.SaveFormatComparator;
import net.minecraft.src.StringTranslate;
import net.minecraft.src.overrideapi.OverrideAPI;
import net.minecraft.src.overrideapi.utils.gui.ButtonHandler;

public class ButtonHandlerSelectWorld implements ButtonHandler {
	private static final Logger LOGGER = WorldSettings.getLogger();
	public static final int CANCEL_BUTTON_ID = 0;
	private int buttonWorldGenID;
	private GuiButton guiButtonWorldGen;
	
	@Override
	public void initGui(GuiScreen guiScreen, List<GuiButton> customButtons) {
		if (guiScreen instanceof GuiSelectWorld) {
			for (int i = 0; i < customButtons.size(); ++i) {
				GuiButton button = customButtons.get(i);
				if (button.id == CANCEL_BUTTON_ID) {
					String displayString = button.displayString;
					button = null;
					customButtons.set(i, new GuiButton(CANCEL_BUTTON_ID, guiScreen.width / 2 + 84, guiScreen.height - 28, 70, 20, displayString));
				}
				
			}
			
			this.buttonWorldGenID = OverrideAPI.getUniqueButtonID();
			StringTranslate stringTranslate = StringTranslate.getInstance();
			this.guiButtonWorldGen = new GuiSelectWorldButton(this.buttonWorldGenID, guiScreen.width / 2 + 4, guiScreen.height - 28, 70, 20, stringTranslate.translateKey(WorldSettings.KEY_LANG_SELECT_WORLD), (GuiSelectWorld)guiScreen);
			customButtons.add(this.guiButtonWorldGen);
			this.whymine_diver = true;
			return;
		}
		
		this.whymine_diver = false;
	}
	
	private boolean whymine_diver = true;

	@Override
	public void actionPerformed(GuiScreen guiScreen, GuiButton guiButton) {
		if (this.whymine_diver && guiScreen instanceof GuiSelectWorld && guiButton == this.guiButtonWorldGen && guiButton.id == this.buttonWorldGenID && guiButton.enabled) {
			GuiSelectWorld guiSelectWorld = (GuiSelectWorld) guiScreen;
			SaveFormatComparator saveFormatComparator = WorldSettings.getSelectedSaveFormatComparator(guiSelectWorld);
			File selectedSaveDirectory = WorldSettings.getSaveDirectory(saveFormatComparator);
			if (selectedSaveDirectory != null && selectedSaveDirectory.exists()) {
				LOGGER.info("Showing save at: " + selectedSaveDirectory.getAbsolutePath());
				ModLoader.getMinecraftInstance().displayGuiScreen(new GuiWorldSettings(guiScreen, saveFormatComparator.getDisplayName() + " \"" + saveFormatComparator.getFileName() + "\"", WorldSettingsConfiguration.getConfigurationDirectory(selectedSaveDirectory)));
				return;
			}
		}
	}

}
