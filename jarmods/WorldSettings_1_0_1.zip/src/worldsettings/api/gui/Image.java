package worldsettings.api.gui;

import java.awt.image.BufferedImage;

import net.minecraft.src.RenderEngine;

public interface Image {
	
	public String getThumbnailPath();
	
	public BufferedImage getThumbnailImage();
	
	public boolean isTextureIDAllocated();
	
	public int getTextureID();
	
	public void setTextureID(int id);

	public default boolean bindThumbnailTexture(RenderEngine renderEngine) {
		if (renderEngine == null) {
			return false;
		}
		
		int textureID = this.getTextureID();
		BufferedImage image = this.getThumbnailImage();
		if (image != null) {
			if (!this.isTextureIDAllocated()) {
				this.setTextureID(renderEngine.allocateAndSetupTexture(image));
			}
			
			renderEngine.bindTexture(textureID);
			return true;
		}
		
		return false;
	}

}
