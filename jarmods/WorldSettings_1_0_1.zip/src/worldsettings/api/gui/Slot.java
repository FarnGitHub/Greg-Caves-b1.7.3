package worldsettings.api.gui;

public interface Slot {
	
	public String getHeadKey();
	
	public String getMainKey();
	
	public String getFootKey();

}
