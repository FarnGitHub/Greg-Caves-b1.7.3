package worldsettings.api.gui.impl;

import net.minecraft.client.Minecraft;
import worldsettings.api.settings.SettingSupplier;

public class GuiButtonSwitch extends GuiButtonCallable {

	private final String settingDisplayString;
	private SettingSupplier<Boolean> setting;

	public GuiButtonSwitch(int id, int x, int y, String displayString, SettingSupplier<Boolean> setting) {
		super(id, x, y, displayString);
		this.setting = setting;
		this.settingDisplayString = displayString;
		this.updateDisplayString();
	}

	public GuiButtonSwitch(int id, int x, int y, int width, int height, String displayString, SettingSupplier<Boolean> setting) {
		super(id, x, y, width, height, displayString);
		this.setting = setting;
		this.settingDisplayString = displayString;
		this.updateDisplayString();
	}

	@Override
	public void onClick() {
		this.setting.setValue(!this.setting.getValue());
		this.updateDisplayString();
	}

	public void updateDisplayString() {
		this.displayString = this.settingDisplayString + (setting.getValue() ? ": ON" : ": OFF"); 
	}
	
	@Override
	public void drawButton(Minecraft minecraft, int xPos, int yPos) {
		this.updateDisplayString();
		super.drawButton(minecraft, xPos, yPos);
	}
	
}
