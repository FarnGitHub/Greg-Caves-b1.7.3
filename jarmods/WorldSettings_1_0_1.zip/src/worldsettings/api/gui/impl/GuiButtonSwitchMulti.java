package worldsettings.api.gui.impl;

import net.minecraft.client.Minecraft;
import worldsettings.api.settings.SettingSupplier;

public class GuiButtonSwitchMulti<T> extends GuiButtonCallable {

    private final SettingSupplier<T> setting;
    private final T[] values;
    private final String[] displayStrings;
    
    private int index = 0;
    private final String settingDisplayString;
    
    public GuiButtonSwitchMulti(int id, int x, int y, int width, int height, String displayString, SettingSupplier<T> setting, T[] values, String[] displayStrings) {
        super(id, x, y, width, height, displayString);
        this.values = values;
        this.setting = setting;
        if (values == null || displayStrings == null || values.length != displayStrings.length) {
            throw new IllegalArgumentException("values and displayStrings arrays must not be null and of equal length");
        }
        
        this.displayStrings = displayStrings;
        this.settingDisplayString = displayString;
    }
    
    public GuiButtonSwitchMulti(int id, int x, int y, String displayString, SettingSupplier<T> setting, T[] values, String[] displayStrings) {
        super(id, x, y, displayString);
        this.values = values;
        this.setting = setting;
        if (values == null || displayStrings == null || values.length != displayStrings.length) {
            throw new IllegalArgumentException("values and displayStrings arrays must not be null and of equal length");
        }
        
        this.displayStrings = displayStrings;
        this.settingDisplayString = displayString;
    }

    @Override
    public void onClick() {
        this.index = (this.index + 1) % this.values.length;
        
        if (this.index >= this.values.length || this.index >= this.displayStrings.length) {
            throw new IndexOutOfBoundsException("The index is out of bounds for the values or displayStrings array.");
        }

        this.setting.setValue(this.values[this.index]);
        this.updateDisplayString();
    }

    public void updateDisplayString() {
        if (this.displayStrings != null && this.displayStrings.length > 0) {
            this.displayString = this.settingDisplayString + ": " + this.displayStrings[this.index];
        } else {
            this.displayString = this.settingDisplayString + ": Invalid display string";
        }
    }
    
    @Override
    public void drawButton(Minecraft minecraft, int xPos, int yPos) {
        this.updateDisplayString();
        super.drawButton(minecraft, xPos, yPos);
    }
}
