package worldsettings.api.gui.impl;

import java.util.ArrayList;

import net.minecraft.src.GuiButton;
import net.minecraft.src.GuiScreen;
import net.minecraft.src.StringTranslate;
import worldsettings.api.gui.ConfigurationScreen;

public class GuiSimpleConfiguration extends GuiScreen implements ConfigurationScreen {
	
	public static final int DONE_BUTTON_ID = 0;
	public static final int LEFT_BUTTON_ID = 1;
	public static final int RIGHT_BUTTON_ID = 2;
	
	private final String langKeyTitle;
	
	protected ArrayList<GuiButton> registeredButtons = new ArrayList<GuiButton>();
	private int nextButtonID = 3;
	private GuiScreen parentScreen = null;
	private int currentPage;
	
	public GuiSimpleConfiguration(String langKeyTitle) {
		this.langKeyTitle = langKeyTitle;
	}
	
	@Override
	public void initGui() {
		this.initButtons();
	}
	
	public int getNextButtonID() {
		return this.nextButtonID++;
	}
	
	public void add(GuiButton button) {
		this.registeredButtons.add(button);
	}
	
	@SuppressWarnings("unchecked")
	public void initButtons() {
		StringTranslate stringTranslate = StringTranslate.getInstance();
		int paddingTop = 25;
		int paddingBottom = 20;

		int buttonWidth = 200;
		int buttonHeight = 20;
		int xSpacing = 10;
		int ySpacing = 10;

		int widthSpacing = buttonWidth + xSpacing;
		int heightSpacing = buttonHeight + ySpacing;

		int usableHeight = this.height - paddingTop - paddingBottom;

		int columns = this.width / widthSpacing;
		int rows = usableHeight / heightSpacing;

		
		
		int buttonsPerPage = columns * rows;
	    int totalButtons = this.registeredButtons.size();
	    int totalPages = Math.max(1, (int) Math.ceil((double) totalButtons / buttonsPerPage));

	    if (this.currentPage >= totalPages) {
	        this.currentPage = totalPages - 1;
	    }
	    
	    if (this.currentPage < 0) {
	        this.currentPage = 0;
	    }

		int startIndex = this.currentPage * buttonsPerPage;
		int endIndex = Math.min(startIndex + buttonsPerPage, this.registeredButtons.size());
		int buttonsOnThisPage = endIndex - startIndex;

		int usedRows = Math.min(rows, (int)Math.ceil((double)buttonsOnThisPage / columns));
		int usedColumns = Math.min(columns, buttonsOnThisPage < columns ? buttonsOnThisPage : columns);

		int totalGridWidth = usedColumns * (buttonWidth + xSpacing) - xSpacing;
		int totalGridHeight = usedRows * (buttonHeight + ySpacing) - ySpacing;

		int xOffset = (this.width - totalGridWidth) / 2;
		int yOffset = paddingTop + (usableHeight - totalGridHeight) / 2;

		for (int i = startIndex; i < endIndex; ++i) {
		    int indexOnPage = i - startIndex;

		    int column = indexOnPage % columns;
		    int row = indexOnPage / columns;

		    int x = xOffset + column * widthSpacing;
		    int y = yOffset + row * heightSpacing;

		    GuiButton button = this.registeredButtons.get(i);
		    button.xPosition = x;
		    button.yPosition = y;
		    this.controlList.add(button);
		}

		GuiButton prevButton = new GuiButton(
				LEFT_BUTTON_ID,
		        this.width / 2 - 125,
		        this.height - 25,
		        20,
		        20,
		        "<"
		);
		
		prevButton.enabled = this.currentPage > 0;
		this.controlList.add(prevButton);
		GuiButton nextButton = new GuiButton(
		    	RIGHT_BUTTON_ID,
		        this.width / 2 + 105,
		        this.height - 25,
		        20,
		        20,
		        ">"
	    );
		
		nextButton.enabled = this.currentPage < totalPages - 1;
		this.controlList.add(nextButton);
		this.controlList.add(
				new GuiButton(
						DONE_BUTTON_ID,
						this.width / 2 - 100,
						this.height - 25,
						stringTranslate.translateKey("gui.done")
				)
		);
	}
	
	@Override
	public void actionPerformed(GuiButton button) {
		if (!button.enabled) {
			return;
		}
		
		if (button.id == DONE_BUTTON_ID) {
			this.mc.displayGuiScreen(this.parentScreen);
			return;
		}
		
		if (button.id == LEFT_BUTTON_ID) {
			--this.currentPage;
			this.controlList.clear();
			this.initButtons();
			return;
		}
		
		if (button.id == RIGHT_BUTTON_ID) {
			++this.currentPage;
			this.controlList.clear();
			this.initButtons();
			return;
		}
		
	}
	
	@Override
	public void drawScreen(int x, int y, float partialTick) {
		this.drawDefaultBackground();
		String page = this.currentPage != 0 ? " (" + this.currentPage + ")" : "";
		this.drawCenteredString(this.fontRenderer, StringTranslate.getInstance().translateKey(this.langKeyTitle) + page, this.width / 2, 20, 0xFFFFFF);
		super.drawScreen(x, y, partialTick);
	}
	
	
	@Override
	public void onGuiClosed() {
	}
	
	@Override
	public void setParentScreen(GuiScreen guiScreen) {
		this.parentScreen = guiScreen;
	}

}
