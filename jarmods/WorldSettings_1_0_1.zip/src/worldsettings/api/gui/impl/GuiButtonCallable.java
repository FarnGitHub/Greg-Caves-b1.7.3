package worldsettings.api.gui.impl;

import net.minecraft.client.Minecraft;
import net.minecraft.src.GuiButton;

public abstract class GuiButtonCallable extends GuiButton  {

	public GuiButtonCallable(int id, int x, int y, String displayString) {
		super(id, x, y, displayString);
	}

	public GuiButtonCallable(int id, int x, int y, int width, int height, String displayString) {
		super(id, x, y, width, height, displayString);
	}

	public abstract void onClick();
	
	@Override
	public boolean mousePressed(Minecraft minecraft, int x, int y) {
		if (this.enabled && x >= this.xPosition && y >= this.yPosition && x < this.xPosition + this.width && y < this.yPosition + this.height) {
			this.onClick();
			return true;
		}
		
		return false;
	}
}
