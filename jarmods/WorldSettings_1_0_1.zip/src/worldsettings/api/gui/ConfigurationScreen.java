package worldsettings.api.gui;

import net.minecraft.src.GuiScreen;
import worldsettings.api.settings.ConfigurationSupplier;

public interface ConfigurationScreen {
	
	public void setParentScreen(GuiScreen guiScreen);
	
	public default void setConfiguration(ConfigurationSupplier configuration) {
		
	}
	
}
