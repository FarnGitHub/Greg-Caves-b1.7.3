package worldsettings.api.settings;

public interface SettingSupplier<T> {
	
	public void resetValue();
	
	public void setValue(T value);
	
	public T getValue();
	
	public T getValueDefault();
	
	public Class<T> getValueClass();
	
	public String getKey();
	
}
