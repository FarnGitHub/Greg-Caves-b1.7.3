package worldsettings.api.settings;

public interface Serializable {
	
	public String serialize();

	public void deserialize(String property);
}
