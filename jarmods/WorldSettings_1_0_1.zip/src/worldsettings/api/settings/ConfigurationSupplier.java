package worldsettings.api.settings;

import java.util.Collection;
import java.util.Map.Entry;
import java.util.Set;

import net.minecraft.client.Minecraft;
import net.minecraft.src.GuiScreen;

public interface ConfigurationSupplier {

	public <T> void put(SettingSupplier<T> object);

	public <T> SettingSupplier<T> get(String key);
	
	public Collection<SettingSupplier<?>> values();
	
	public Set<Entry<String, SettingSupplier<?>>> entrySet();

	public Set<String> keySet();
	
	public String getName();

	public void reset();
	
	public void displayGUI(Minecraft minecraft, GuiScreen guiScreen);

}
