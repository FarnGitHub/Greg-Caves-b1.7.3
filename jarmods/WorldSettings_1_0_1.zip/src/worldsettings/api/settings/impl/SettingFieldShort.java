package worldsettings.api.settings.impl;

import java.lang.reflect.Field;

public class SettingFieldShort extends SettingField<Short> {
	
	public SettingFieldShort(String key, Short value, Short valueDefault, Object object, Field field) {
		super(key, value, valueDefault, Short.class, object, field);
	}

	public SettingFieldShort(String key, Short valueDefault, Object object, Field field) {
		super(key, valueDefault, Short.class, object, field);	
	}

	@Override
	protected void updateField() {
		Field field = this.field;
		if (field.getType() == short.class) {
			field.setAccessible(true);
			try {
				field.setShort(this.object, this.getValue());
			} catch (IllegalArgumentException | IllegalAccessException e) {
				e.printStackTrace();
			}
			
		}
		
	}
	
}
