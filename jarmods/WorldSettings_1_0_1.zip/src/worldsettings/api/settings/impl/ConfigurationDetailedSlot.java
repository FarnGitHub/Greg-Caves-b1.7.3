package worldsettings.api.settings.impl;

import net.minecraft.src.GuiScreen;
import worldsettings.api.gui.Slot;

public class ConfigurationDetailedSlot extends ConfigurationBasic implements Slot {
	private final String headKey;
	private final String mainKey;
	private final String footKey;
	
	public ConfigurationDetailedSlot(GuiScreen configurationScreen, String name, String headKey, String mainKey, String footKey) {
		super(configurationScreen, name);
		this.headKey = headKey;
		this.mainKey = mainKey;
		this.footKey = footKey;
	}

	@Override
	public String getHeadKey() {
		return this.headKey;
	}

	@Override
	public String getMainKey() {
		return this.mainKey;
	}

	@Override
	public String getFootKey() {
		return this.footKey;
	}

}
