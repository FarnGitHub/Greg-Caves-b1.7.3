package worldsettings.api.settings.impl;

import java.lang.reflect.Field;

public class SettingFieldFloat extends SettingField<Float> {
	
	public SettingFieldFloat(String key, Float value, Float valueDefault, Object object, Field field) {
		super(key, value, valueDefault, Float.class, object, field);
	}

	public SettingFieldFloat(String key, Float valueDefault, Object object, Field field) {
		super(key, valueDefault, Float.class, object, field);	
	}

	@Override
	protected void updateField() {
		Field field = this.field;
		if (field.getType() == float.class) {
			field.setAccessible(true);
			try {
				field.setFloat(this.object, this.getValue());
			} catch (IllegalArgumentException | IllegalAccessException e) {
				e.printStackTrace();
			}
			
		}
		
	}
	
}
