package worldsettings.api.settings.impl;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import java.util.logging.Logger;

import javax.imageio.ImageIO;

import net.minecraft.src.GuiScreen;
import worldsettings.WorldSettings;
import worldsettings.api.gui.Image;

public class ConfigurationDetailedSlotImage extends ConfigurationDetailedSlot implements Image {
	private static final Logger LOGGER = WorldSettings.getLogger();
	private final String thumbnailPath;
	private int imageID;
	
	public ConfigurationDetailedSlotImage(GuiScreen configurationScreen, String name, String head, String main, String foot, String thumbnailPath) {
		super(configurationScreen, name, head, main, foot);
		this.thumbnailPath = thumbnailPath;
		this.setTextureID(-1);
	}

	@Override
	public String getThumbnailPath() {
		return this.thumbnailPath;
	}

	@Override
	public BufferedImage getThumbnailImage() {
		try {
			String thumbnailPath = this.getThumbnailPath();
			if (thumbnailPath == null) {
				LOGGER.severe("Thumbnail path is missing from: " + this);
				return null;
			}
			
			URL url = getClass().getResource(thumbnailPath);
			if (url == null) {
				LOGGER.severe("Could not resolve: " + thumbnailPath);
				return null;
			}
			
			return ImageIO.read(url);
		} catch (IOException e) {
			return null;
		}
	}

	@Override
	public boolean isTextureIDAllocated() {
		return this.imageID != -1;
	}

	@Override
	public int getTextureID() {
		return this.imageID;
	}

	@Override
	public void setTextureID(int id) {
		this.imageID = id;
	}

}
