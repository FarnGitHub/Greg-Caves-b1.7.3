package worldsettings.api.settings.impl;

import java.lang.reflect.Field;

public class SettingField<T> extends Setting<T> {
	protected final Field field;
	protected final Object object;
	
	public SettingField(String key, T valueDefault, Class<T> valueClass, Object object, Field field) {
		super(key, valueDefault, valueClass);
		this.object = object;
		this.field = field;
		this.updateField();
	}

	public SettingField(String key, T value, T valueDefault, Class<T> valueClass, Object object, Field field) {
		super(key, value, valueDefault, valueClass);
		this.object = object;
		this.field = field;
		this.updateField();
	}

	@Override
	public void setValue(T value) {
		super.setValue(value);
		this.updateField();
	}
	
	@Override
	public void resetValue() {
		super.resetValue();
		this.updateField();
	}
	
	protected void updateField() {
		T value = this.getValue();
		Field field = this.field;
		if (field.getType().isAssignableFrom(value.getClass())) {
			field.setAccessible(true);
			try {
				field.set(this.object, value);
			} catch (IllegalArgumentException | IllegalAccessException e) {
				e.printStackTrace();
			}
			
		}
		
	}
	
}
