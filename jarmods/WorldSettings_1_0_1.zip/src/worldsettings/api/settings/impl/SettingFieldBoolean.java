package worldsettings.api.settings.impl;

import java.lang.reflect.Field;

public class SettingFieldBoolean extends SettingField<Boolean> {
	
	public SettingFieldBoolean(String key, Boolean value, Boolean valueDefault, Object object, Field field) {
		super(key, value, valueDefault, Boolean.class, object, field);
	}

	public SettingFieldBoolean(String key, Boolean valueDefault, Object object, Field field) {
		super(key, valueDefault, Boolean.class, object, field);	
	}

	@Override
	protected void updateField() {
		Field field = this.field;
		if (field.getType() == boolean.class) {
			field.setAccessible(true);
			try {
				field.setBoolean(this.object, this.getValue());
			} catch (IllegalArgumentException | IllegalAccessException e) {
				e.printStackTrace();
			}
			
		}
		
	}
	
}
