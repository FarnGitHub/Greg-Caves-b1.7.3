package worldsettings.api.settings.impl;

import java.lang.reflect.Field;

public class SettingFieldInt extends SettingField<Integer> {
	
	public SettingFieldInt(String key, Integer value, Integer valueDefault, Object object, Field field) {
		super(key, value, valueDefault, Integer.class, object, field);
	}

	public SettingFieldInt(String key, Integer valueDefault, Object object, Field field) {
		super(key, valueDefault, Integer.class, object, field);	
	}

	@Override
	protected void updateField() {
		Field field = this.field;
		if (field.getType() == int.class) {
			field.setAccessible(true);
			try {
				field.setInt(this.object, this.getValue());
			} catch (IllegalArgumentException | IllegalAccessException e) {
				e.printStackTrace();
			}
			
		}
		
	}
	
}
