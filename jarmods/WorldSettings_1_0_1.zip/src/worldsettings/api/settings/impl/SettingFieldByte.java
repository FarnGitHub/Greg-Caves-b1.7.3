package worldsettings.api.settings.impl;

import java.lang.reflect.Field;

public class SettingFieldByte extends SettingField<Byte> {
	
	public SettingFieldByte(String key, Byte value, Byte valueDefault, Object object, Field field) {
		super(key, value, valueDefault, Byte.class, object, field);
	}

	public SettingFieldByte(String key, Byte valueDefault, Object object, Field field) {
		super(key, valueDefault, Byte.class, object, field);	
	}

	@Override
	protected void updateField() {
		Field field = this.field;
		if (field.getType() == byte.class) {
			field.setAccessible(true);
			try {
				field.setByte(this.object, this.getValue());
			} catch (IllegalArgumentException | IllegalAccessException e) {
				e.printStackTrace();
			}
			
		}
		
	}
	
}
