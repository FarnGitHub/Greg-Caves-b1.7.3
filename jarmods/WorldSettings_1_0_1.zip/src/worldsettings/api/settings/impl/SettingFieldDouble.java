package worldsettings.api.settings.impl;

import java.lang.reflect.Field;

public class SettingFieldDouble extends SettingField<Double> {
	
	public SettingFieldDouble(String key, Double value, Double valueDefault, Object object, Field field) {
		super(key, value, valueDefault, Double.class, object, field);
	}

	public SettingFieldDouble(String key, Double valueDefault, Object object, Field field) {
		super(key, valueDefault, Double.class, object, field);	
	}

	@Override
	protected void updateField() {
		Field field = this.field;
		if (field.getType() == double.class) {
			field.setAccessible(true);
			try {
				field.setDouble(this.object, this.getValue());
			} catch (IllegalArgumentException | IllegalAccessException e) {
				e.printStackTrace();
			}
			
		}
		
	}
	
}
