package worldsettings.api.settings.impl;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import net.minecraft.client.Minecraft;
import net.minecraft.src.GuiScreen;
import worldsettings.api.gui.ConfigurationScreen;
import worldsettings.api.settings.ConfigurationSupplier;
import worldsettings.api.settings.SettingSupplier;

public class ConfigurationBasic implements ConfigurationSupplier {
	public final String name;
	private final Map<String, SettingSupplier<?>> map = new HashMap<>();
	private final GuiScreen configurationScreen;

	public ConfigurationBasic(GuiScreen configurationScreen, String name) {
		this.configurationScreen = configurationScreen;
		this.name = name;
	}

	@Override
	public <T> void put(SettingSupplier<T> object) {
		this.map.put(object.getKey(), object);
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> SettingSupplier<T> get(String key) {
		return (SettingSupplier<T>) this.map.get(key);
	}

	@Override
	public Collection<SettingSupplier<?>> values() {
		return this.map.values();
	}

	@Override
	public Set<Entry<String, SettingSupplier<?>>> entrySet() {
		return this.map.entrySet();
	}

	@Override
	public Set<String> keySet() {
		return this.map.keySet();
	}

	@Override
	public String getName() {
		return this.name;
	}

	@Override
	public void reset() {
		for (SettingSupplier<?> setting : this.values()) {
			setting.resetValue();
		}
	}

	@Override
	public void displayGUI(Minecraft minecraft, GuiScreen parentScreen) {
		if (minecraft == null || parentScreen == null) {
			return;
		}

		if (this.configurationScreen instanceof ConfigurationScreen) {
			((ConfigurationScreen) this.configurationScreen).setParentScreen(parentScreen);
		}
		
		minecraft.displayGuiScreen(this.configurationScreen);
	}

}
