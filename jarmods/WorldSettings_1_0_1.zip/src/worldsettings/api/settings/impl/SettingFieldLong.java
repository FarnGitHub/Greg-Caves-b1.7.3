package worldsettings.api.settings.impl;

import java.lang.reflect.Field;

public class SettingFieldLong extends SettingField<Long> {
	
	public SettingFieldLong(String key, Long value, Long valueDefault, Object object, Field field) {
		super(key, value, valueDefault, Long.class, object, field);
	}

	public SettingFieldLong(String key, Long valueDefault, Object object, Field field) {
		super(key, valueDefault, Long.class, object, field);	
	}

	@Override
	protected void updateField() {
		Field field = this.field;
		if (field.getType() == long.class) {
			field.setAccessible(true);
			try {
				field.setLong(this.object, this.getValue());
			} catch (IllegalArgumentException | IllegalAccessException e) {
				e.printStackTrace();
			}
			
		}
		
	}
	
}
