package worldsettings.api.settings.impl;

import java.lang.reflect.Field;

public class SettingFieldChar extends SettingField<Character> {
	
	public SettingFieldChar(String key, Character value, Character valueDefault, Object object, Field field) {
		super(key, value, valueDefault, Character.class, object, field);
	}

	public SettingFieldChar(String key, Character valueDefault, Object object, Field field) {
		super(key, valueDefault, Character.class, object, field);	
	}

	@Override
	protected void updateField() {
		Field field = this.field;
		if (field.getType() == char.class) {
			field.setAccessible(true);
			try {
				field.setChar(this.object, this.getValue());
			} catch (IllegalArgumentException | IllegalAccessException e) {
				e.printStackTrace();
			}
			
		}
		
	}
	
}
