package worldsettings.api.settings.impl;

import java.util.Objects;

import worldsettings.api.settings.SettingSupplier;

public class Setting<T> implements SettingSupplier<T> {
	private final String key;
	private final T valueDefault;
	private T value;
	private final Class<T> valueClass;
	
	public Setting(String key, T valueDefault, Class<T> valueClass) {
		this.key = key;
		this.valueDefault = valueDefault;
		this.value = valueDefault;
		this.valueClass = valueClass;
	}
	
	public Setting(String key, T value, T valueDefault, Class<T> valueClass) {
		this.key = key;
		this.valueDefault = valueDefault;
		this.value = value;
		this.valueClass = valueClass;
	}
	
	@Override
	public void setValue(T value) {
		this.value = value;
	}
	
	@Override
	public void resetValue() {
		this.value = this.valueDefault;
	}

	@Override
	public T getValue() {
		return this.value;
	}
	
	@Override
	public T getValueDefault() {
		return this.valueDefault;
	}
	
	@Override
	public Class<T> getValueClass() {
		return this.valueClass;
	}

	@Override
	public String getKey() {
		return this.key;
	}

	@Override
	public int hashCode() {
		return Objects.hash(this.getKey());
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof SettingSupplier))
			return false;
		SettingSupplier<?> other = (SettingSupplier<?>) obj;
		return Objects.equals(this.getKey(), other.getKey());
	}

}
