package worldsettings;

import java.util.ArrayList;
import java.util.List;

import org.lwjgl.opengl.GL11;

import net.minecraft.client.Minecraft;
import net.minecraft.src.FontRenderer;
import net.minecraft.src.GuiSlot;
import net.minecraft.src.RenderEngine;
import net.minecraft.src.StringTranslate;
import net.minecraft.src.Tessellator;
import worldsettings.api.gui.Image;
import worldsettings.api.gui.Slot;
import worldsettings.api.settings.ConfigurationSupplier;

public class GuiWorldSettingsSlot extends GuiSlot {
	private final List<ConfigurationSupplier> list;
	private int elementSelected;
	
	private GuiWorldSettings parentScreen;
	
	public GuiWorldSettingsSlot(GuiWorldSettings parentScreen) {
		super(GuiWorldSettings.getMinecraft(parentScreen), parentScreen.width, parentScreen.height, 32, parentScreen.height - 55 + 4, 36);
		this.parentScreen = parentScreen;
		this.list = new ArrayList<>(WorldSettingsConfiguration.getConfigurations());
		this.elementSelected = -1;
	}

	@Override
	protected int getSize() {
		return this.list.size();
	}
	
	public ConfigurationSupplier getSelectedConfiguration() {
		int index = this.elementSelected;
		if (this.list == null || index < 0 || index > this.getSize()) {
			return null;
		}
		
		return this.list.get(index);
	}

	@Override
	protected void elementClicked(int index, boolean bool) {
		this.elementSelected = index;
		this.parentScreen.enableButtons();
	}
	
	public void deselectButton() {
		this.elementSelected = -1;
	}

	@Override
	protected boolean isSelected(int index) {
		return this.elementSelected == index;
	}

	@Override
	protected void drawBackground() {
		this.parentScreen.drawDefaultBackground();
	}

	@Override
	protected void drawSlot(int index, int x, int y, int height, Tessellator tessellator) {
		Minecraft minecraft = GuiWorldSettings.getMinecraft(this.parentScreen);
		if (minecraft == null) {
			return;
		}
		
		ConfigurationSupplier configuration = this.list.get(index);
		if (configuration == null) {
			return;
		}
		
		if (configuration instanceof Image) {
			RenderEngine renderEngine = minecraft.renderEngine;
			if (renderEngine != null && ((Image) configuration).bindThumbnailTexture(renderEngine)) {
				GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
				tessellator.startDrawingQuads();
				tessellator.setColorOpaque_I(16777215);
				tessellator.addVertexWithUV((double)x, (double)(y + height), 0.0D, 0.0D, 1.0D);
				tessellator.addVertexWithUV((double)(x + 32), (double)(y + height), 0.0D, 1.0D, 1.0D);
				tessellator.addVertexWithUV((double)(x + 32), (double)y, 0.0D, 1.0D, 0.0D);
				tessellator.addVertexWithUV((double)x, (double)y, 0.0D, 0.0D, 0.0D);
				tessellator.draw();
			}
		} else {
			x -= 32;
		}
		
		FontRenderer fontRenderer = minecraft.fontRenderer;
		if (fontRenderer == null) {
			return;
		}
		
		if (configuration instanceof Slot) {
			Slot slot = (Slot) configuration;
			StringTranslate stringTranslate = StringTranslate.getInstance();
			this.parentScreen.drawString(fontRenderer, stringTranslate.translateKey(slot.getHeadKey()), x + 32 + 2, y + 1, 0xFFFFFF);
			this.parentScreen.drawString(fontRenderer, stringTranslate.translateKey(slot.getMainKey()), x + 32 + 2, y + 12, 0x808080);
			this.parentScreen.drawString(fontRenderer, stringTranslate.translateKey(slot.getFootKey()), x + 32 + 2, y + 12 + 10, 0x808080);
		} else {
			String name = configuration.getName();
			if (name != null && !name.isEmpty()) {
				this.parentScreen.drawString(fontRenderer, name, x + 32 + 2, y + 1, 0xFFFFFF);
			}
		}
	}

}
