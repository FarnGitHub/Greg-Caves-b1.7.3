package worldgen;

import java.util.Set;

import net.minecraft.src.BaseMod;
import net.minecraft.src.ModLoader;
import net.minecraft.src.World;
import net.minecraft.src.mod_WorldGeneratorOverrides;
import worldgen.api.ChunkProviderGenerator;
import worldgen.api.GenerationEnabled;
import worldsettings.WorldSettingsConfiguration;
import worldsettings.api.gui.impl.GuiSimpleConfiguration;
import worldsettings.api.settings.ConfigurationSupplier;
import worldsettings.api.settings.SettingSupplier;
import worldsettings.api.settings.impl.ConfigurationDetailedSlot;
import worldsettings.api.settings.impl.Setting;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.logging.Logger;
import java.util.Random;

public class WorldGeneratorOverrides {
	
	private static final Logger LOGGER = Logger.getLogger("World Generator Overrides");
	
	public static final String RANDOM_LEVEL_SOURCE_STRING = "RandomLevelSource";
	public static final String HELL_RANDOM_LEVEL_SOURCE_STRING = "HellRandomLevelSource";
	
	public static final String KEY_LANG_GENERATOR_MENU = "worldgen.menu.overrides";
	public static final String KEY_LANG_MODLOADER_MENU = "worldgen.menu.modloader";
	public static final String KEY_LANG_CUSTOM_GENERATE_SURFACE = "worldgen.menu.modloader.generatesurface";
	public static final String KEY_LANG_CUSTOM_GENERATE_NETHER = "worldgen.menu.modloader.generatenether";
	public static final String KEY_LANG_CUSTOMIZE_DEFAULT_SETTINGS = "worldgen.menu.modloader.customize";
	
	static final Map<ChunkProviderGenerator, SettingSupplier<Boolean>> ENABLED_CHUNK_PROVIDERS = new HashMap<>();
	private static final GuiSimpleConfiguration GENERATOR_GUI = new GuiGeneratorConfiguration();
	private static final ConfigurationSupplier GENERATOR_CONFIGURATION = new ConfigurationDetailedSlot(GENERATOR_GUI, "worldgengenerator", KEY_LANG_GENERATOR_MENU, "", "");;
	private static long lastTimeLoaded;
	
	static final SettingSupplier<Boolean> CUSTOM_GENERATE_SURFACE_SETTING = new Setting<Boolean>("CustomModLoaderGenerateSurface", false, Boolean.class);
	private static Map<BaseMod, SettingSupplier<Boolean>> modsOverridingGenerateSurface;
	private static final GuiSimpleConfiguration GENERATE_SURFACE_GUI = new GuiSurfaceGenerationConfiguration();
	private static final ConfigurationSupplier GENERATE_SURFACE_CONFIGURATION = new ConfigurationDetailedSlot(GENERATE_SURFACE_GUI, "worldgenmodloadersurface", KEY_LANG_CUSTOM_GENERATE_SURFACE, "", "");
	
	static final SettingSupplier<Boolean> CUSTOM_GENERATE_NETHER_SETTING = new Setting<Boolean>("CustomModLoaderGenerateNether", false, Boolean.class);
	private static Map<BaseMod, SettingSupplier<Boolean>> modsOverridingGenerateNether;
	private static final GuiSimpleConfiguration GENERATE_NETHER_GUI = new GuiNetherGenerationConfiguration();
	private static final ConfigurationSupplier GENERATE_NETHER_CONFIGURATION = new ConfigurationDetailedSlot(GENERATE_NETHER_GUI, "worldgenmodloadernether", KEY_LANG_CUSTOM_GENERATE_NETHER, "", "");

	public static void init() {
		LOGGER.info("Adding localization");
		ModLoader.AddLocalization(KEY_LANG_MODLOADER_MENU, mod_WorldGeneratorOverrides.langModLoaderMenu);
		ModLoader.AddLocalization(KEY_LANG_CUSTOM_GENERATE_SURFACE, mod_WorldGeneratorOverrides.langCustomGenerateSurfaceButton);
		ModLoader.AddLocalization(KEY_LANG_CUSTOM_GENERATE_NETHER, mod_WorldGeneratorOverrides.langCustomGenerateNetherButton);
		ModLoader.AddLocalization(KEY_LANG_CUSTOMIZE_DEFAULT_SETTINGS, mod_WorldGeneratorOverrides.langCustomizeDefaultSettings);
		ModLoader.AddLocalization(KEY_LANG_GENERATOR_MENU, mod_WorldGeneratorOverrides.langGeneratorMenu);
	}
	
	@SuppressWarnings("unchecked")
	public static void modsLoaded() {
		LOGGER.info("Getting mods that override world generation methods");
		setModsOverridingGenerators((List<BaseMod>) ModLoader.getLoadedMods());
		LOGGER.info("Adding settings to ModLoader GUI's");
		GENERATE_SURFACE_CONFIGURATION.put(CUSTOM_GENERATE_SURFACE_SETTING);
		GENERATE_NETHER_CONFIGURATION.put(CUSTOM_GENERATE_NETHER_SETTING);
		LOGGER.info("Registering CONFIGURATIONS");
		WorldSettingsConfiguration.registerConfiguration(GENERATOR_CONFIGURATION);
		WorldSettingsConfiguration.registerConfiguration(GENERATE_SURFACE_CONFIGURATION);
		WorldSettingsConfiguration.registerConfiguration(GENERATE_NETHER_CONFIGURATION);
	}
	
	@SuppressWarnings("unchecked")
	public static <T extends ChunkProviderGenerator> Set<T> getChunkProviderGenerators(Class<T> generatorClass) {
		Set<T> filteredSet = new HashSet<>();
		for (Entry<ChunkProviderGenerator, SettingSupplier<Boolean>> entry : ENABLED_CHUNK_PROVIDERS.entrySet()) {
			ChunkProviderGenerator value = entry.getKey();
			if (generatorClass.isAssignableFrom(value.getClass()) && entry.getValue().getValue()) {
				filteredSet.add((T) value);
			}
			
		}
		
		return filteredSet;
	}
			
	private static void setModsOverridingGenerators(List<BaseMod> mods) {
		Map<BaseMod, SettingSupplier<Boolean>> modsSurface = new LinkedHashMap<>();
		Map<BaseMod, SettingSupplier<Boolean>> modsNether = new LinkedHashMap<>();
		for (BaseMod mod : mods) {
				Class<?> modClass = mod.getClass();
				final Method generateSurfaceMethod = getGenerationMethod(modClass, "GenerateSurface");
				final Method generateNetherMethod = getGenerationMethod(modClass, "GenerateNether");
				boolean surface = true;
				boolean nether = true;
				if (mod instanceof GenerationEnabled) {
					GenerationEnabled generationEnabled = (GenerationEnabled) mod;
					surface = generationEnabled.isSurfaceEnabled();
					nether = generationEnabled.isNetherEnabled();
				}
				
				if (isModMethodOverriden(generateSurfaceMethod)) {
					Setting<Boolean> setting = new Setting<Boolean>(mod.getClass().getSimpleName(), surface, Boolean.class);
					GENERATE_SURFACE_CONFIGURATION.put(setting);
					modsSurface.put(mod, setting);
					
				}
				
				if (isModMethodOverriden(generateNetherMethod)) {
					Setting<Boolean> setting = new Setting<Boolean>(mod.getClass().getSimpleName(), nether, Boolean.class);
					GENERATE_NETHER_CONFIGURATION.put(setting);
					modsNether.put(mod, setting);
				}
		}
		
		modsOverridingGenerateSurface = modsSurface;
		modsOverridingGenerateNether = modsNether;
	}
			
	private static Method getGenerationMethod(Class<?> clazz, String methodName) {
		try {
			return clazz.getDeclaredMethod(methodName, World.class, Random.class, int.class, int.class);
		} catch (Exception e) {
			
		}
		
		return null;
	}
	
	private static boolean isModMethodOverriden(Method method) {
		return method != null && method.getDeclaringClass() != BaseMod.class;
	}
	
	static void setEnabledChunkProviderOverride(ChunkProviderGenerator generator, boolean flag) {
		ENABLED_CHUNK_PROVIDERS.get(generator).setValue(flag);
	}
	
	public static void addChunkProviderOverride(ChunkProviderGenerator generator) {
		SettingSupplier<Boolean> setting = new Setting<Boolean>(generator.getDisplayString(), false, Boolean.class);
		ENABLED_CHUNK_PROVIDERS.put(generator, setting);
		if (GENERATOR_CONFIGURATION != null) {
			GENERATOR_CONFIGURATION.put(setting);
			lastTimeLoaded = System.currentTimeMillis();
		}
		
	}
	
	public static boolean isCustomGenerationEnabledSurface() {
		return CUSTOM_GENERATE_SURFACE_SETTING.getValue();
	}
	
	public static String getGenerateMakeString() {
		return isCustomGenerationEnabledSurface() ? mod_WorldGeneratorOverrides.customRandomLevelSourceName : RANDOM_LEVEL_SOURCE_STRING;
	}
	
	public static Map<BaseMod, SettingSupplier<Boolean>> getModsOverridingGenerateSurface() {
		return modsOverridingGenerateSurface;
	}
	
	public static boolean isCustomGenerationEnabledNether() {
		return CUSTOM_GENERATE_NETHER_SETTING.getValue();
	}
	
	public static String getHellMakeString() {
		return isCustomGenerationEnabledNether() ? mod_WorldGeneratorOverrides.customHellRandomLevelSourceName : HELL_RANDOM_LEVEL_SOURCE_STRING;
	}
	
	public static Map<BaseMod, SettingSupplier<Boolean>> getModsOverridingGenerateNether() {
		return modsOverridingGenerateNether;
	}
	
	public static long getLastTimeLoaded() {
		return lastTimeLoaded;
	}
	
}
