package worldgen.api;

import java.util.Random;

import net.minecraft.src.BiomeGenBase;
import net.minecraft.src.Chunk;
import net.minecraft.src.ChunkProviderSky;

public abstract class ChunkProviderSkyGenerator extends ChunkProviderGenerator {

	public ChunkProviderSkyGenerator(String displayString) {
		super(displayString);	
	}

	public void preTerrain(ChunkProviderSky provider, Random seed, byte[] blocks, Chunk chunk, BiomeGenBase[] biomes, double[] temperature) {};
	
	public void preReplaceBlocks(ChunkProviderSky provider, Random seed, byte[] blocks, Chunk chunk, BiomeGenBase[] biomes, double[] temperature) {};

	public void preCaves(ChunkProviderSky provider, Random seed, byte[] blocks, Chunk chunk, BiomeGenBase[] biomes, double[] temperature) {};

	public void preLight(ChunkProviderSky provider, Random seed, byte[] blocks, Chunk chunk, BiomeGenBase[] biomes, double[] temperature) {};
	
	public void post(ChunkProviderSky provider, Random seed, byte[] blocks, Chunk chunk, BiomeGenBase[] biomes, double[] temperature) {};
	
}
