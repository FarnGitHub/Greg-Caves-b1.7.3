package worldgen.api;

import java.util.Random;

import net.minecraft.src.Chunk;
import net.minecraft.src.ChunkProviderHell;

public abstract class ChunkProviderHellGenerator extends ChunkProviderGenerator {

	public ChunkProviderHellGenerator(String displayString) {
		super(displayString);
	}

	public void preTerrain(ChunkProviderHell chunkProvider, Random seed, byte[] blocks) {};
	
	public void preReplaceBlocks(ChunkProviderHell chunkProvider, Random seed, byte[] blocks) {};

	public void preCaves(ChunkProviderHell chunkProvider, Random seed, byte[] blocks) {};

	public void post(ChunkProviderHell chunkProvider, Random seed, byte[] blocks, Chunk chunk) {};
	
}
