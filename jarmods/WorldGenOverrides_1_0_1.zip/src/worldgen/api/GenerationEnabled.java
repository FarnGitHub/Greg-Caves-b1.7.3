package worldgen.api;

public interface GenerationEnabled {

	public boolean isSurfaceEnabled();

	public boolean isNetherEnabled();

}
