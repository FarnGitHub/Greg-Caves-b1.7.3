package worldgen.api;

import java.util.Random;

import net.minecraft.src.BiomeGenBase;
import net.minecraft.src.Chunk;
import net.minecraft.src.ChunkProviderGenerate;

public abstract class ChunkProviderGenerateGenerator extends ChunkProviderGenerator {

	public ChunkProviderGenerateGenerator(String displayString) {
		super(displayString);
	}

	public void preTerrain(ChunkProviderGenerate chunkProvider, Random random, byte[] blocks, Chunk chunk, BiomeGenBase[] biomes, double[] temperature) {};
	
	public void preReplaceBlocks(ChunkProviderGenerate chunkProvider, Random seed, byte[] blocks, Chunk chunk, BiomeGenBase[] biomes, double[] temperature) {};

	public void preCaves(ChunkProviderGenerate chunkProvider, Random seed, byte[] blocks, Chunk chunk, BiomeGenBase[] biomes, double[] temperature) {};

	public void preLight(ChunkProviderGenerate chunkProvider, Random seed, byte[] blocks, Chunk chunk, BiomeGenBase[] biomes, double[] temperature) {};
	
	public void post(ChunkProviderGenerate chunkProvider, Random seed, byte[] blocks, Chunk chunk, BiomeGenBase[] biomes, double[] temperature) {};
	
}
