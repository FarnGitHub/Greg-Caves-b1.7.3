package worldgen.api;

public abstract class ChunkProviderGenerator {
	
	private final String displayString;
	
	public ChunkProviderGenerator(String displayString) {
		this.displayString = displayString;
	}
	
	public String getDisplayString() {
		return this.displayString;
	}
}
