package worldgen;

import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;

import net.minecraft.src.BaseMod;
import net.minecraft.src.GuiButton;
import net.minecraft.src.StringTranslate;
import worldsettings.api.gui.impl.GuiButtonSwitch;
import worldsettings.api.gui.impl.GuiSimpleConfiguration;
import worldsettings.api.settings.SettingSupplier;

public class GuiSurfaceGenerationConfiguration extends GuiSimpleConfiguration {

	private List<GuiButton> settingButtons;
	private GuiButtonSwitch switchButton;
	
	public GuiSurfaceGenerationConfiguration() {
		super(WorldGeneratorOverrides.KEY_LANG_CUSTOM_GENERATE_SURFACE);
	}
	
	@Override
	public void initGui() {
		this.registeredButtons.clear();
		this.registeredButtons.add(
				this.switchButton = new GuiButtonSwitch(
						this.getNextButtonID(),
						0,
						0,
						StringTranslate.getInstance().translateKey(WorldGeneratorOverrides.KEY_LANG_CUSTOMIZE_DEFAULT_SETTINGS),
						WorldGeneratorOverrides.CUSTOM_GENERATE_SURFACE_SETTING
				)
		);
		
		boolean enabled = WorldGeneratorOverrides.isCustomGenerationEnabledSurface();
		this.settingButtons = new ArrayList<GuiButton>();
		for (Entry<BaseMod, SettingSupplier<Boolean>> entry : WorldGeneratorOverrides.getModsOverridingGenerateSurface().entrySet()) {
			GuiButton button = new GuiButtonSwitch(this.getNextButtonID(), 0, 0, entry.getKey().getClass().getSimpleName(), entry.getValue());
			this.registeredButtons.add(button);
			this.settingButtons.add(button);
			button.enabled = enabled;
		}
			
		this.initButtons();
	}
		
	@Override
	public void actionPerformed(GuiButton button) {
		super.actionPerformed(button);
		if (button == this.switchButton) {
			boolean buttonState = WorldGeneratorOverrides.isCustomGenerationEnabledSurface();
			for (GuiButton settingButton : this.settingButtons) {
				settingButton.enabled = buttonState;
			}
			
		}
		
	}

}
