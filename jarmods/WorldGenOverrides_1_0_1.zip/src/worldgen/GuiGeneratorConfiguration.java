package worldgen;

import java.util.Map.Entry;

import worldgen.api.ChunkProviderGenerator;
import worldsettings.api.gui.impl.GuiButtonSwitch;
import worldsettings.api.gui.impl.GuiSimpleConfiguration;
import worldsettings.api.settings.SettingSupplier;

public class GuiGeneratorConfiguration extends GuiSimpleConfiguration {

	public GuiGeneratorConfiguration() {
		super(WorldGeneratorOverrides.KEY_LANG_GENERATOR_MENU);
	}
	
	@Override
	public void initGui() {
		this.registeredButtons.clear();
		for (Entry<ChunkProviderGenerator, SettingSupplier<Boolean>> entry : WorldGeneratorOverrides.ENABLED_CHUNK_PROVIDERS.entrySet()) {
			this.registeredButtons.add(new GuiButtonSwitch(this.getNextButtonID(), 0, 0, entry.getKey().getDisplayString(), entry.getValue()));
		}
		
		this.initButtons();
	}

}
